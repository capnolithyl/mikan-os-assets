# Optional Mikan PowerShell prompt. Dot-source in your own session or profile.
function global:prompt {
    $previousSuccess = $?
    $esc = [char]27
    $amber = "${esc}[38;2;255;173;92m"
    $cream = "${esc}[38;2;255;241;229m"
    $rose = "${esc}[38;2;255;145;141m"
    $reset = "${esc}[0m"
    $statusColor = if ($previousSuccess) { $amber } else { $rose }
    $location = $ExecutionContext.SessionState.Path.CurrentLocation
    "${amber}Mikan${reset} ${cream}$location${reset} `n${statusColor}>${reset} "
}
